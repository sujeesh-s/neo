		<!-- Jquery js-->
		<script src="{{URL::asset('admin/assets/js/jquery-3.5.1.min.js')}}"></script>

		<!-- Bootstrap4 js-->
		<script src="{{URL::asset('admin/assets/plugins/bootstrap/popper.min.js')}}"></script>
		<script src="{{URL::asset('admin/assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>

		<!--Othercharts js-->
		<script src="{{URL::asset('admin/assets/plugins/othercharts/jquery.sparkline.min.js')}}"></script>

		<!-- Circle-progress js-->
		<script src="{{URL::asset('admin/assets/js/circle-progress.min.js')}}"></script>

		<!-- Jquery-rating js-->
		<script src="{{URL::asset('admin/assets/plugins/rating/jquery.rating-stars.js')}}"></script>
		@yield('js')
		<!-- Custom js-->
		<script src="{{URL::asset('admin/assets/js/custom.js')}}"></script>