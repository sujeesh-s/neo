<style type="text/css">
    

.h-100vh.bg-primary {
    background-color: <?php echo e(config('settings.bg_primary_color')); ?>  !important;
    background-image: url("<?php echo e(URL::asset(config('settings.bg_primary_image'))); ?>");
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
#bgred{
    background-color:  <?php echo e(config('settings.dashboard_bg')); ?>  !important;
}
.side-menu__icon {
        color: <?php echo e(config('settings.menu_icon_color')); ?> !important;
    fill: <?php echo e(config('settings.menu_icon_color')); ?> !important;
}
.btn-secondary {
    background-color: <?php echo e(config('settings.btn_secondary')); ?> ;
    border-color: <?php echo e(config('settings.btn_secondary')); ?> ;
}
.page-item.active .page-link {
    background-color: <?php echo e(config('settings.active_link')); ?> !important;
    border-color: <?php echo e(config('settings.active_link')); ?> !important;
}
#back-to-top {
    background: <?php echo e(config('settings.back_to_top')); ?> !important;
}
.btn-primary {
    color: #fff !important;
    background-color: <?php echo e(config('settings.btn_primary')); ?> !important;
    border-color: <?php echo e(config('settings.btn_primary')); ?> !important;
    box-shadow: 0 0px 10px -5px rgb(112 94 200 / 50%);
}
.btn-info {
    color: #fff !important;
    background-color:  <?php echo e(config('settings.btn_info')); ?> !important;
    border-color:  <?php echo e(config('settings.btn_info')); ?> !important;
    box-shadow: 0 0px 10px -5px rgb(91 127 255 / 50%);
}
 </style><?php /**PATH C:\xampp\htdocs\kangto\resources\views/includes/config-styles.blade.php ENDPATH**/ ?>