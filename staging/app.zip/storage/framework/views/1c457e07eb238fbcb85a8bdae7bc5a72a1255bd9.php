<div class="tab-pane active " id="tab1">
    <div class="card-header mb-4""><div class="card-title">Basic Information</div></div>
    <div class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('business_name','Business Name',['class'=>''])); ?> <span class="text-red">*</span>
            <?php echo e(Form::text('info[business_name]',$bName,['id'=>'business_name', 'class'=>'form-control','placeholder'=>'Business Name'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div id="filter_div" class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('store_name','Store Name',['class'=>''])); ?> <span class="text-red">*</span>
            <?php echo e(Form::text('info[store_name]',$sName,['id'=>'store_name', 'class'=>'form-control','placeholder'=>'Store Name'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('email','Email Type',['class'=>''])); ?> <span class="text-red">*</span>
            <?php echo e(Form::text('info[email]',$email,['id'=>'email', 'class'=>'form-control','placeholder'=>'Email'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div id="data_type_div" class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('phone','Phone',['class'=>''])); ?> <span class="text-red">*</span>
            <?php echo e(Form::text('info[phone]',$phone,['id'=>'phone', 'class'=>'form-control','placeholder'=>'Phone'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div id="config_div" class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('licence','Licence',['class'=>''])); ?>

            <?php echo e(Form::text('info[licence]',$licence,['id'=>'licence', 'class'=>'form-control','placeholder'=>'Licence'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('director_name','Director Name',['class'=>''])); ?> <span class="text-red">*</span>
            <?php echo e(Form::text('info[director_name]',$name,['id'=>'director_name','class'=>'form-control','placeholder'=>'Director Name'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('ic_number','Director IC Number',['class'=>''])); ?>

            <?php echo e(Form::text('info[ic_number]',$name,['id'=>'ic_number','class'=>'form-control','placeholder'=>'Director IC Number'])); ?>

            <span class="error"></span>
        </div>
    </div> 
    <div class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('incharge_name','Incharge Name',['class'=>''])); ?>

            <?php echo e(Form::text('info[incharge_name]',$icName,['id'=>'incharge_name','class'=>'form-control','placeholder'=>'Incharge Name'])); ?>

            <span class="error"></span>
        </div>
    </div>
    <div class="col-lg-6 fl">
        <div class="form-group">
            <?php echo e(Form::label('incharge_phone','Incharge Phone',['class'=>''])); ?>

            <?php echo e(Form::text('info[incharge_phone]',$icPhone,['id'=>'incharge_phone','class'=>'form-control','placeholder'=>'Incharge Phone'])); ?>

            <span class="error"></span>
        </div>
    </div> 
    <div class="col-lg-6 fl">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('logo','Logo',['class'=>''])); ?>

                    <?php echo e(Form::file('image[logo]',['id'=>'logo','class'=>'form-control'])); ?>

                    <span class="error"></span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <img id="logoImg" src="<?php echo e($logoImg); ?>" alt="Logo" height="70" />
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 fl">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('banner','Store Banner',['class'=>''])); ?>

                    <?php echo e(Form::file('image[banner]',['id'=>'banner','class'=>'form-control'])); ?>

                    <span class="error"></span>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <img id="bannerImg" src="<?php echo e($bannerImg); ?>" alt="Banner" height="120" />
                </div>
            </div>
        </div>
    </div> 
</div>
                        <?php /**PATH /home/ktestrradoweb/public_html/resources/views/admin/seller/details/basic_info.blade.php ENDPATH**/ ?>