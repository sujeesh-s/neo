
<?php $__env->startSection('css'); ?>
		<!-- INTERNAl Data table css -->
		<link href="<?php echo e(URL::asset('admin/assets/plugins/datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('admin/assets/plugins/datatable/css/buttons.bootstrap4.min.css')); ?>"  rel="stylesheet">
		<!-- <link href="<?php echo e(URL::asset('admin/assets/plugins/datatable/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" /> -->
		<link href="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/jquery.sweet-modal.min.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/sweetalert.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
						<!--Page header-->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title mb-0"><?php echo e($title); ?></h4>
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="#"><i class="fe fe-grid mr-2 fs-14"></i>Blog Management</a></li>
									
									<li class="breadcrumb-item active" aria-current="page"><a href="#"><?php echo e($title); ?></a></li>
								</ol>
							</div>
							<div class="page-rightheader" style="display:flex; flex-direction: row; justify-content: center; align-items: center">
								<div class="btn btn-list">
									<a href="<?php echo e(url('/admin/blog/newcategory')); ?>"   class="btn btn-primary addmodule"><i class="fe fe-plus mr-1"></i> Add New</a>
								</div>
							</div>
						</div>
                        <!--End Page header-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
						<!-- Row -->
						<div class="row flex-lg-nowrap">
							<div class="col-12">
								
								<div class="row flex-lg-nowrap">
									<div class="col-12 mb-3">
										<div class="e-panel card">
											<div class="card-body">
												<div class="e-table">
													<div class="table-responsive table-lg mt-3">
														<table class="table table-bordered border-top text-nowrap blogcategorylist" id="blogcategorylist">
															<thead>
																<tr>
																	<th class="align-top border-bottom-0 wd-5 userroles">Select</th>
																	<th class="border-bottom-0 w-20">Name</th>
																	<th class="border-bottom-0 w-15">Created At</th>
																	<th class="border-bottom-0 w-15">Updated At</th>						
																	<th class="border-bottom-0 w-30">Status</th>						
																	<th class="border-bottom-0 w-10 userroles">Actions</th>
																</tr>
															</thead>

															<tbody>
																<?php if($blog_categories && count($blog_categories) > 0): ?> <?php $n= 0; ?>
																	<?php $__currentLoopData = $blog_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $n++; ?>
																		<!-- <?php if($row->is_active == 1){ $active = "Active"; $checked = 'checked'; }else if ($row->is_active == 0){ $active = "Inactive"; $checked = ""; } ?> -->
																		<tr>
																			<td class="align-middle select-checkbox">
																				<span class=""></span>
																			</td>
																			<td class="align-middle">
																				<h6 class="mb-0 font-weight-bold"><?php echo e(ucfirst($row->bc_name)); ?></h6>
																			</td>
																			<td class="text-nowrap align-middle">
																				<span><?php echo e(date('d M Y',strtotime($row->created_at))); ?></span>
																			</td>
																			<td class="align-middle">
																				<span><?php echo e(date('d M Y',strtotime($row->updated_at))); ?></span>
																			</td> 
																			<?php if($row->is_deleted == 1) {?>

																			<td>
																				<div class="btn-list">
																					<a href="#" class="btn btn-light disabled">Inactive</a>
																				</div>
																			</td>
																			<?php } else{ ?>
																				<td class="text-nowrap align-middle" data-search="<?php if($row->is_active==1): ?><?php echo e('Published'); ?><?php else: ?><?php echo e('Draft'); ?><?php endif; ?>">
																				<div class="switch">
																					<input class="switch-input status-btn ser_status" data-selid="<?php echo e($row->bc_id); ?>" id="status-<?php echo e($row->bc_id); ?>"  data-id="<?php echo e($row->bc_id); ?>" name="status" type="checkbox"  <?php if($row->is_active==1): ?> <?php echo e("checked"); ?> <?php endif; ?> >
																					<label class="switch-paddle" for="status-<?php echo e($row->bc_id); ?>">
																						<span class="switch-active" aria-hidden="true">Published</span>
																						<span class="switch-inactive" aria-hidden="true">Draft</span>
																					</label>
																				</div>
																			</td>
																			<?php } ?>
																			<td class="align-middle">
																				<?php if($row->is_deleted == 1) {?>
																					<div class="btn-list">
																					<a href="#" class="btn btn-danger disabled">Deleted</a>
																				</div>
																				<?php } else{ ?>
																					<div class="btn-group align-top">
																						<a href="<?php echo e(url('admin/blog/editcategory/'.$row->bc_id)); ?>"   class="btn btn-sm btn-info mr-2"><i class="fe fe-edit mr-1"></i> Edit</a>
																						<button  class="btn btn-sm btn-secondary deletecategory" type="button" onclick="delete_cat(<?php echo $row->bc_id;?>)"><i class="fe fe-trash-2"></i>Delete</button>
																					</div>
																				<?php } ?>
																				
																			</td>
																		</tr>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>	
																
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->


						<!-- User Form Modal -->
								

					</div>
				</div><!-- end app-content-->
            </div>
            
<style type="text/css">
table.dataTable tr.parent {
animation: none !important;
}
table.dataTable tr.selected p {
color: #fff;
}


</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
		
			<script src="<?php echo e(URL::asset('admin/assets/js/datatable/tables/blogcategory-datatable.js')); ?>"></script>
	<!-- INTERNAL Popover js -->
		<script src="<?php echo e(URL::asset('admin/assets/js/popover.js')); ?>"></script>

		<!-- INTERNAL Sweet alert js -->
		<script src="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/jquery.sweet-modal.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('admin/assets/js/sweet-alert.js')); ?>"></script>
<script type="text/javascript">

		$(document).ready(function(){
					<?php if(Session::has('message')): ?>
						<?php if(session('message')['type'] =="success"): ?>
					
							toastr.success("<?php echo e(session('message')['text']); ?>"); 
						<?php else: ?>
							toastr.error("<?php echo e(session('message')['text']); ?>"); 
						<?php endif; ?>
					<?php endif; ?>
					
			});

	function delete_cat(cpnid){
		$('body').removeClass('timer-alert');
			swal({
				title: "Delete Confirmation",
				text: "Are you sure you want to delete this Category?",
				showCancelButton: true,
				closeOnConfirm: true,
				confirmButtonText: 'Yes'
			},function(inputValue){
				if (inputValue == true) {
						$.ajax({
						type: "POST",
						url: '<?php echo e(url("/admin/blog/categorydelete")); ?>',
						data: { "_token": "<?php echo e(csrf_token()); ?>", bcat_id: cpnid},
						success: function (data) {
								location.reload();
						}
					});
				}
			});
	}

	jQuery(document).ready(function(){
		$(".ser_status").on("click", function(e){
				var selid = jQuery(this).data("selid");
				var sestatus='0';
				if($(this).prop('checked') == true)
				{
				sestatus='1';
				}
				
				$.ajax({
					type: "POST",
					url: '<?php echo e(url("/admin/blog/categorystatus")); ?>',
					data: { "_token": "<?php echo e(csrf_token()); ?>", bcat_id: selid,status:sestatus},
					success: function (data) {
						// alert(data);
						if(data) {
							if(sestatus ==1) {
								jQuery('#status-'+selid).closest("td").attr("data-search","Active");
							toastr.success("Blog Category Published Successfully.");   
							}else {
								jQuery('#status-'+selid).closest("td").attr("data-search","Inactive");
							toastr.success("Blog Category Status updated successfully.");  
							}
							var table = $.fn.dataTable.tables( { api: true } );
							table.rows().invalidate().draw();
						
						}else {
						toastr.error("Failed to update status."); 	
						}
					}
				});
		});
	});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\neobench\resources\views/admin/blog/category/list.blade.php ENDPATH**/ ?>