<?php $currency = getCurrency()->name; ?>
<div class="row flex-lg-nowrap">
    <div class="col-12">
        <div class="row flex-lg-nowrap">
            <div class="col-12 mb-3">
                <div class="e-panel card">
                    <div id="data-content" class="card-body">
                       
                        <div id="table_body" class="card-body table-card-body">
                            <div>
                                    <table id="prdreview" class="prdreview table table-striped table-bordered w-100 text-nowrap">
                                    <thead>
                                        <tr>
                                            <th class="wd-15p">#</th>
                                            <th class="wd-15p">Product Name</th>
                                            <th class="wd-15p">No.of reviews</th>
                                            <th class="wd-15p">No.of rating</th>
                                            <th class="wd-15p">Last review</th>
                                            <th class="wd-15p">Action</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php if($data && count($data) > 0): ?> <?php $n = 0; ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $n++; ?> 
                                    <tr>    
                                        <td class="align-middle select-checkbox"></td>
                                        <td><?php echo e($row['product_name']); ?></td>
                                        <td><?php echo e($row['reviews']); ?></td>
                                        <td><?php echo e($row['rating']); ?></td>
                                        <td><span style="display: block;width: 100px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;"><?php echo e($row['latest']); ?></span></td>
                                        <?php $view=$row['view']; ?>
                                        <td><button id="viewBtn-<?php echo $view ?>" class="mr-2 btn btn-success btn-sm viewBtn"><i class="fa fa-eye mr-1"></i>View</button></td>
                                    </tr>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                </table>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 <script src="<?php echo e(asset('admin/assets/js/datatable/tables/prdreviews-datatable.js')); ?>"></script>
 <script type="text/javascript">
     $(document).ready(function(){
        $('#filters').show(); 
     });
 </script>
 <?php /**PATH C:\xampp\htdocs\kangto\resources\views/admin/prdreview_report/list.blade.php ENDPATH**/ ?>