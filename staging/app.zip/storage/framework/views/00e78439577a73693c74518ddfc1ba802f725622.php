<div class="tab-pane" id="tab3">
    <div class="card-header mb-4"><div class="card-title">Store Settings</div></div>
    <div class="col-lg-4 col-md-6 fl">
        <div class="form-group">
            <div class="text-muted">Store Categories</div>
            <div class="font-weight-bold">
                <?php if($store->storeCategories && count($store->storeCategories) > 0): ?> <?php $__currentLoopData = $store->storeCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span id="<?php echo e($cat->id); ?>"><?php echo e($cat->category->cat_name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6 fl d-none">
        <div class="form-group">
        </div>
    </div>
    <div class="col-lg-4 col-md-6 fl d-none">
        <div class="form-group">
        </div>
    </div>
    <div class="col-lg-4 col-md-6 fl d-none">
        <div class="form-group">
        </div>
    </div>
    <div class="col-lg-4 col-md-6 fl">
        <div class="form-group">
            <div class="text-muted">Commission</div><div class="font-weight-bold"><?php echo e($store->commission); ?></div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6 fl">
        <div class="form-group">
            <div class="text-muted">Status</div><div class="font-weight-bold"><?php echo $active; ?></div>
        </div>
    </div>
</div>
                    <?php /**PATH /home/ktestrradoweb/public_html/resources/views/admin/seller/view/store_settings.blade.php ENDPATH**/ ?>