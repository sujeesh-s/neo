
<?php $__env->startSection('css'); ?>
		<!-- INTERNAl Data table css -->
		<link href="<?php echo e(URL::asset('admin/assets/plugins/datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('admin/assets/plugins/datatable/css/buttons.bootstrap4.min.css')); ?>"  rel="stylesheet">
		<link href="<?php echo e(URL::asset('admin/assets/plugins/datatable/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/jquery.sweet-modal.min.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/sweetalert.css')); ?>" rel="stylesheet" />
				<link href="<?php echo e(URL::asset('admin/assets/css/combo-tree.css')); ?>" rel="stylesheet" />
		<link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.0.45/css/materialdesignicons.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
						<!--Page header-->


						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title mb-0"><?php echo e($title); ?></h4>
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="#"><i class="fe fe-grid mr-2 fs-14"></i>Ecom Benefits</a></li>
									
									<li class="breadcrumb-item active" aria-current="page"><a href="#"><?php echo e($title); ?></a></li>
								</ol>
							</div>
							<div class="page-rightheader">
								
							</div>
						</div>
                        <!--End Page header-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
						<!-- Row -->
						<div class="row flex-lg-nowrap">
							<div class="col-12">

								<div class="row flex-lg-nowrap">
									<div class="col-12 mb-3">
										<div class="e-panel card">
											<div class="card-body">
												<div class="e-table">
				
													<div class="table-responsiv table-lg mt-3">
														
<?php echo e(Form::open(array('url' => "admin/rewards/save", 'id' => 'rewardsForm', 'name' => 'rewardsForm', 'class' => '','files'=>'true'))); ?>


<?php if(isset($rewards['id'])): ?> 
<input type="hidden" name="id" value="<?php echo e($rewards['id']); ?>">	
<?php else: ?>
<input type="hidden" name="id" value="0">	
<?php endif; ?>
								
<div class="row mt-4">
	<div class="card">
		<div class="card-header">
			<h3 class="card-title">Invite & Earn Settings</h3>
		</div>
		
	</div>
	<div class="col-lg-12">
		<div class="expanel expanel-default">
			<div class="expanel-heading">
				<h3 class="expanel-title">Referral Cashback Options</h3>
			</div>
					<div class="row">
					<div class="col-lg-6">
					<div class="expanel-body">
					<div class="custom-controls-stacked">
						<?php //dd($rewards['all_types']); ?>
						<?php if($rewards && count($rewards['all_types']) > 0): ?>
						<?php $__currentLoopData = $rewards['all_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<label class="custom-control custom-radio">
				<input type="radio" class="custom-control-input reward_type" onclick="loadOptions();" id="rwd_type" name="rwd_type" value="<?php echo e($row['id']); ?>" <?php if($rewards['rwd_type']==$row['id']){ echo "checked";}?>>
				<span class="custom-control-label"><?php echo e($row['rwd_type_title']); ?></span>
				</label>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					
					


					</div>
					</div>
					</div>

					<div class="col-lg-6" style="min-height: 175px;">
					<div class="expanel-body">


	<?php if($rewards && count($rewards['all_types']) > 0): ?>
						<?php $__currentLoopData = $rewards['all_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




				<?php if($row['id'] !=3): ?>
				<div  class="reward_type_options points_<?php echo e($row['id']); ?>" >
				<label class="form-label" for="points_<?php echo e($row['id']); ?>" ><?php echo e($row['rwd_type_title']); ?> Points <span class="text-red">*</span></label>
				<input min="1" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
    type = "number"
    maxlength = "6" step="1" type="number" name="reward_points[<?php echo e($row['id']); ?>]" id="points_<?php echo e($row['id']); ?>" class="form-control"  <?php if($rewards['rwd_type'] == $row['id'] || $rewards['rwd_type'] == 3): ?>  value="<?php echo e($row['points']); ?>" <?php endif; ?> />
				</div>
				<?php endif; ?>


						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>


					

					

					</div>
					</div>
					</div>

<div class="row">
<div class="col-lg-6">
<div class="expanel-body">
<div  class="referral-points" >
<label class="form-label" for="point_val" >Referral Point Value <span class="text-red">*</span></label>
<input min="1" step="1" type="number" name="point_val" id="point_val" <?php if(isset($rewards['point_val'])): ?> value="<?php echo e($rewards['point_val']); ?>" <?php endif; ?> placeholder="Point equivalent
 to amount" class="form-control"  />
</div>

</div>
</div>

<div class="col-lg-6">
<!-- <div class="expanel-body">
<div  class="purchase_type_options purchase-number" >
<label class="form-label" for="purchase_number" >Purchase Number <span class="text-red">*</span></label>
<input min="1" step="1" type="number" name="purchase_number" id="purchase_number" class="form-control"  />
</div>

</div> -->
</div>


		</div>
	</div>

	<div class="col-lg-12">
		<div class="expanel expanel-default">
			<div class="expanel-heading">
				<h3 class="expanel-title">First Order Cash Back/Discount</h3>
			</div>
			<div class="row">
			<div class="col-lg-6">
			<div class="expanel-body">
			<div  class="first_order" >
			<label class="form-label" for="ord_amount" >Amount <span class="text-red">*</span></label>
			<input min="1" step="1" type="number" name="ord_amount" id="ord_amount" <?php if(isset($rewards['ord_amount'])): ?> value="<?php echo e($rewards['ord_amount']); ?>" <?php endif; ?>  class="form-control"  />
			</div>
			</div>
			</div>

			<div class="col-lg-6">
			<div class="expanel-body">
			<label class="form-label" for="ord_type">Type </label>

<?php 

if(isset($rewards['ord_type'])) {

if($rewards['ord_type'] == "cashback")
{

$cashback = "selected";
$discount = ""; 
}
else
{

$discount = "selected"; 
$cashback = ""; 
}
} else {
$cashback = ""; 
$discount = "";
}
 ?> 
			<select class="form-control" name="ord_type" id="ord_type">
			<option value="cashback" <?php echo e($cashback); ?> >Cashback</option>
			<option value="discount" <?php echo e($discount); ?> >Discount</option>

			</select>

			</div>
			</div>
			</div>

<div class="row">
<div class="col-lg-6">
<div class="expanel-body">
<div  class="purchase_type_options purchase-number" >
<label class="form-label" for="ord_min_amount" >Minimum Order Amount <span class="text-red">*</span></label>
<input min="1" step="1" type="number" name="ord_min_amount" id="ord_min_amount" <?php if(isset($rewards['ord_min_amount'])): ?> value="<?php echo e($rewards['ord_min_amount']); ?>" <?php endif; ?>   class="form-control"  />
</div>
</div>
</div>

<div class="col-lg-6">
<!-- <div class="expanel-body">
<label class="form-label">Type </label>

<select class="form-control" name="category_id" id="category_id" required onchange="loadsubcat()">
<option value="cashback">Cashback</option>
<option value="discount">Discount</option>

</select>

</div> -->
</div>
</div>

		</div>
	</div>


												
														
														
														<div class="row">
															<div class="col d-flex justify-content-end">
															
															<input class="btn btn-primary" type="submit" id="frontval" value="Save Changes">
															</div>
														</div>
													
												</div>
												<?php echo e(Form::close()); ?>


													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->


						
							

					</div>
				</div><!-- end app-content-->
            </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
		<!-- INTERNAl Data tables -->
<script src="<?php echo e(URL::asset('admin/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin/assets/js/bootstrap-datepicker.js')); ?>"></script>
	<!-- INTERNAL Popover js -->
		<script src="<?php echo e(URL::asset('admin/assets/js/popover.js')); ?>"></script>

		<!-- INTERNAL Sweet alert js -->
		<script src="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/jquery.sweet-modal.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('admin/assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('admin/assets/js/sweet-alert.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin/assets/js/comboTreePlugin.js')); ?>"></script>


<script type="text/javascript">
	jQuery(document).ready(function(){


$("#frontval").click(function(){

$("#rewardsForm").validate({
rules: {


"reward_points[2]": {
required: function(){
return (''+$("#rwd_type[value='2']:checked").val() !="" || $("#rwd_type[value='3']:checked").val() !="") ;
}, 
number: true,
min: 1
},
"reward_points[1]": {
required: function(){
return (''+$("#rwd_type[value='1']:checked").val() !="" || $("#rwd_type[value='3']:checked").val() !="") ;
}, 
number: true,
min: 1
},

point_val : {
required: true,
min: 1
},
ord_amount : {
required: true,
min: 1
},
ord_min_amount : {
required: true,
min: 1
},



},

messages : {
"reward_points[2]": {
required: "First Purchase Points is required."
},
"reward_points[1]": {
required: "Register Points is required."
},
point_val: {
required: "Referral Point Value is required.",
min: "Referral Point Value must be greater than 0"
},
ord_amount: {
required: "Amount is required.",
min: "Amount must be greater than 0"
},
ord_min_amount: {
required: "Minimum Order Amount is required.",
min: "Minimum Order Amount must be greater than 0"
}
},
 errorPlacement: function(error, element) {
 	 $("#errNm1").empty();
            if (element.attr("name") == "ofr_code" ) {
                $("#errNm1").text($(error).text());
                
            }else {
               error.insertAfter(element)
            }
        },

});
});


	});
</script>

<script type="text/javascript">
    $(document).ready(function(){
            <?php if(Session::has('message')): ?>
            <?php if(session('message')['type'] =="success"): ?>
            
            toastr.success("<?php echo e(session('message')['text']); ?>"); 
            <?php else: ?>
            toastr.error("<?php echo e(session('message')['text']); ?>"); 
            <?php endif; ?>
            <?php endif; ?>
            
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>"); 
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
    });
    </script>


<script type="text/javascript">
$(document).ready(function(){

loadOptions();



});

function loadOptions(){

var cu_val = $("[name='rwd_type']:checked").val();
$(".reward_type_options").hide('1000');  
if(cu_val == 3) {
$(".reward_type_options").show('1000'); 
}else {
$(".points_"+cu_val).show('1000');	
} 

}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kangto\resources\views/admin/benefits/rewards/view.blade.php ENDPATH**/ ?>